module.exports = {
	devServer:{
		open:true,
		proxy:{
			'/oapi':{
				// 接口地址
				target:"https://www.opposhop.cn/",
				// 打开跨区请求 允许
				changeOrigin:true,
				onProxyReq(proxyReq,req,res){
					// 设置请求头
					// proxyReq.setHeader("referer","https://www.opposhop.cn/cn/m/cart/index"),
					proxyReq.setHeader("source_type","504")
					proxyReq.setHeader("Content-Type","application/json")
					// Referer: https://www.opposhop.cn/cn/m/cart/index
					// source_type: 504
				}
			},
			'php':{
				target:"https://520mg.com/",
				changeOrigin:true
			}
		}
	}
}