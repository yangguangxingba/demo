<template>
	<div>
		<!-- 返回键 start -->
		<van-icon name="arrow-left" @click="$router.back()"/>
		<!-- 返回键 end -->
		
		<div class="header">
			<van-tabs v-model="activeName" title-active-color='#f63434'>
				
				<!-- 商品详情页面 start -->
				<van-tab title="商品详情" name="a">
					<!-- 轮播图 start -->
					<van-swipe @change="onChange" autoplay="3000" class="my-swipe">
						<van-swipe-item v-for="(item,index) in list.duoDuanDetailImages" :key="index">
							<img :src="item.url" alt="" width="100%">
						</van-swipe-item>
						<template #indicator>
							<div class="custom-indicator">{{ current + 1 }}/{{list.duoDuanDetailImages.length}}</div>
						</template>
					</van-swipe>
					<!-- 轮播图 end -->

					<!-- 参数滑动栏 start -->
					<div class="listsell">
						<ul class="listsells">
							<li v-for="(item,index) in list.listSellMaps" :key="index">
								<div>
									<img :src="item.icon" alt="">
									<p>{{item.title}}</p>
									<p class="twop">{{item.subTitle}}</p>
								</div>
							</li>
						</ul>
					</div>
					<!-- 参数滑动栏 end -->
					
					<!-- 商品详情 start -->
					<div class="istitle">
						<div>
							<h1>{{list.name}}</h1>
							<div v-html="list.defaultSlogan" class="text"></div>
							<div class="price">¥{{list.price}}</div>
						</div>
					</div>
					<!-- 商品详情 end -->
					
					<!-- 商品规格选择 start -->
					<div class="sku">
						<div class="skumain">
							<div class="rows" v-for="(item,index) in list.attributes.configs" :key="index">
								<div class="title">
									{{item.name}}
								</div>
								<div v-for="(item,ind) in item.values" :key="ind" class="btn" @click="shopChange(index,item.item)" :class="{'primary': item.item == temattr1[index]}">
									{{item.item}}
								</div>
							</div>
						</div>
					</div>
					<!-- 商品规格选择 end -->
					
					<!-- 内容底部图片start -->
					<div>
						<img :src="item.url" alt="" v-for="(item,index) in list.duoDuanDescriptionImages" :key="index" width="100%">
					</div>
					<!-- 内容底部图片end -->
					
				</van-tab>
				<!-- 商品详情页面 end -->
				
				<!-- 用户评价页面 start -->
				<van-tab title="用户评价" name="b">
					<van-empty description="暂无评论" />
				</van-tab>
				<!-- 用户评价页面 end -->
				
				<!-- 参数及包装页面 start -->
				<van-tab title="参数及包装" name="c">
					<img :src="item.url" alt="" v-for="(item,index) in list.specImagesMaps" :key="index" width="100%">
				</van-tab>
				<!-- 参数及包装页面 end -->
				
			</van-tabs>
		</div>
		
		<!-- 底部购物导航 start -->
		<div class="btmnev">
			<div class="left" @click="$router.push('/')">
				<van-icon name="wap-home-o" />
				<span>首页</span>
			</div>
			<div class="left">
				<van-icon name="service-o" />
				<span>客服</span>
			</div>
			<div class="left" @click="$router.push('/cart')">
				<van-icon name="cart-o" :badge="$store.getters.totalNum" />
				<span>购物车</span>
			</div>
			<div class="right">
				<button @click="purchase()">加入购物车</button>
				<button class="two">立即购买</button>
			</div>
		</div>
		<!-- 底部购物导航 end -->
		
	</div>
</template>

<script>
	// 获取商品数据接口
	import { GetCate } from '@/api/cate/cate.js'
	export default {
		data() {
			return {
				temattr:{},
				activeName: 'a',
				list: {},
				current: 0,
				twos:[],
				temattr1:[]
			}
		},
		methods: {
			
			// 加入购物车
			purchase(){
				var arrr= this.list.attributes.skuItems.filter(item => {
					var flag=true
					var ary=Object.values(item)
					for(var i=0;i<ary.length-1;i++){
						if(ary[i]!=this.temattr1[i]){
							flag=false
						}
					}
					return flag
				})
				GetCate(
				'/cn/oapi/goods/web/info/skuId?skuId=' + arrr[0].skuId
				).then(res=>{
					this.$store.commit('addGoods',res.data.data)
				})
			},
			
			// 选择商品规格
			shopChange(index,data){
				this.$set(this.temattr1,index,data)
			},
			
			// 此商品详情数据
			getDetail() {
				GetCate(
					'/cn/oapi/goods/web/info/skuId?skuId=' + this.$route.params.id
				).then(res => {
					this.list = res.data.data
					this.temattr=res.data.data.attributes.skuItems.find(item=>item.skuId==this.$route.params.id)
					this.temattr1=Object.values(this.temattr)
					console.log(res.data.data.attributes.skuItems)
				})
			},
			
			// 滑动轮播图
			onChange(index) {
				this.current = index;
			}
		},
		created() {
			this.getDetail()
		}
	}
</script>

<style>
	.van-tabs--line .van-tabs__wrap {
		height: .81rem;
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		background-color: #fff;
		z-index: 9;
		font-size: .24rem;
	}
	.van-tabs__wrap .van-tabs__nav .van-tab .van-tab__text{
		font-size: .24rem;
		line-height: .24rem;
	}
	.van-tab__pane{
		margin-top: .81rem;
	}
</style>

<style scoped="scoped">
	.van-icon-arrow-left {
		font-size: .46rem;
		line-height: .81rem;
		margin-left: .2rem;
		color: rgb(246, 52, 52);
		position: fixed;
		top: 0;
		left: -.2rem;
		z-index: 999;
	}
	.van-tabs__content{
		margin-top: .81rem;
		
	}
	.van-tab {
		line-height: .81rem;
	}
	
	.van-tabs {
		flex: 1;
		width: 100%;
	}
	
	.van-tab__text {
		font-size: .28rem;
		z-index: 999;
	}
	
	.custom-indicator {
		position: absolute;
		right: 5px;
		bottom: 5px;
		padding: 2px 5px;
		font-size: 12px;
		background: rgba(0, 0, 0, 0.1);
	}
	
	.custom-indicator {
		width: .69rem;
		height: .42rem;
		font-size: .24rem;
		text-align: center;
		line-height: .42rem;
		color: #fff;
		font-size: .24rem;
		background: #000;
		border-radius: 0.1rem;
		opacity: .3;
		margin-right: .24rem;
		margin-bottom: .16rem;
	}
	.van-empty__image{
		width:auto;
		height:auto;
	}
	.sku{
		width: 100%;
		background-color: #f7f8fa;
		padding: .2rem .24rem;
	}
	.sku .skumain{
		background-color: #fff;
		border-radius: 0.21rem;
		padding: .32rem 0 .12rem;
	}
	.sku .skumain .rows{
		display: flex;
		font-size: .26rem;
		align-items: center;
		margin-bottom: .2rem;
		flex-wrap: wrap;
	}
	.sku .skumain .rows .title{
		margin: 0.2rem 0.15rem 0.24rem;
		color: #666;
		font-size: .26rem;
		white-space: nowrap;
	}
	.sku .skumain .rows .btn{
		color: #333;
		background-color: #f7f8fa;
		border: 0.02rem solid transparent;
		margin-right: 0.16rem;
		padding: 0.15rem 0.2rem;
		color: #000;
		font-size: .26rem;
		white-space: nowrap;
		text-overflow: ellipsis;
		border-radius: 0.1rem;
	}
	.btmnev{
		height: 1.2rem;
		position: fixed;
		bottom: 0;
		left: 0;
		right: 0;
		display: flex;
		background-color: #fff;
		color: #333;
		font-size: .22rem;
	}
	.btmnev button{
		height: 0.72rem;
		font-size: .28rem;
		color: #fff;
		border: none;
		background-color: #ff722c;
		border-radius: 2em;
		min-width: 2.04rem;
		padding: 0 0.12rem;
	}
	.btmnev .left{
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		width: 0.96rem;
	}
	.van-info{
		font-size: .26rem;
		height: .35rem;
		width: .35rem;
		line-height: .35rem;
		border-radius: 50%;
		top: .06rem;
		right: .06rem;
	}
	.btmnev .left .van-icon{
		font-size: .48rem;
		font-weight: 900;
		color: #333;
	}
	.btmnev .right{
		flex: 1;
		display: flex;
		justify-content: space-evenly;
		align-items: center;
	}
	.btmnev .right .two{
		background-color: #f63434;
	}
	.swipe {
		width: 100%;
	}

	.listsell ul {
		display: flex;
		overflow-x: auto;
		background-color: #f7f8fa;
	}
	.listsell ul::-webkit-scrollbar { width: 0 !important }
	.listsell ul li div {
		display: flex;
		flex-direction: column;
		align-items: center;
		height: 1.65rem;
		width: 1.66rem;
	}

	.listsell ul li img {
		width: .48rem;
		height: .48rem;
		margin-top: .26rem;
	}

	.listsell ul li p {
		height: .32rem;
		padding-top: .08rem;
		line-height: .24rem;
		font-size: .24rem;
		color: #333333;
	}

	.listsell ul li .twop {
		font-size: .2rem;
		color: #666;
	}
	
	.istitle{
		width: 100%;
		background-color: #f7f8fa;
	}
	.istitle>div{
		margin: 0 0.24rem;
		padding: 0 0.24rem 0.32rem 0.24rem;
		overflow: hidden;
		background: #fff;
		border-radius: 0.16rem;
	}
	.istitle h1{
		margin: 0.32rem 0 .2rem;
		overflow: hidden;
		color: #333;
		font-weight: 500;
		font-size: .34rem;
		line-height: .6rem;
	}
	.istitle .text{
		line-height: .35rem;
		font-size: .26rem;
		overflow: hidden;
	}
	.istitle>div .price{
		margin-top: 0.22rem;
		font-size: .38rem;
		color: #F63434;
		font-weight: 500;
		line-height: .38rem;
	}
	.sku .skumain .rows .primary{
		color: #f63434;
		background: #fff;
		border: 0.02rem solid #f63434;
	}
</style>
