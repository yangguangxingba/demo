<template>
	<div class="user">
		<!-- 顶部用户信息 start -->
		<div class="header">
			<div class="myuser">
				<div class="userimg">
					<img src="../../assets/userno.png" alt="" v-if="!$store.state.userInfo.M_LoginID">
					<img src="../../assets/u.jpg" alt="" v-else>
				</div>
				<div class="usercontainer">
					<div class="username" v-if="!$store.state.userInfo.M_LoginID">登录账号</div>
					<div class="username" v-else>{{$store.state.userInfo.M_LoginID}}</div>
					<div class="userid">体验更多功能</div>
				</div>
				<button @click="$router.push('/login')" v-if="!$store.state.userInfo.M_LoginID">登录</button>
			</div>
			
			<div class="header-property">
				<div>
					<div class="property-value" v-if="!$store.state.userInfo.M_LoginID">--</div>
					<div v-else>0</div>
					<div class="property-name">优惠卷</div>
				</div>
				<div>
					<div class="property-value" v-if="!$store.state.userInfo.M_LoginID">--</div>
					<div v-else>0</div>
					<div class="property-name">回收代金券</div>
				</div>
				<div>
					<div class="property-value" v-if="!$store.state.userInfo.M_LoginID">--</div>
					<div v-else>{{$store.state.userInfo.M_Scores}}</div>
					<div class="property-name">积分</div>
				</div>
			</div>
		</div>
		<!-- 顶部用户信息 end -->
		
		<!-- 订单与常用工具栏 start -->
		<div class="main">
			<div class="top">
				<div class="title">
					<span>我的订单</span>
					<span class="last">全部订单 ›</span>
				</div>
				<div class="list">
					<ul>
						<li>
							<van-icon name="balance-list-o" class="listicon" />
							<span>待付款</span>
						</li>
						<li>
							<van-icon name="todo-list-o" class="listicon" />
							<span>待发货</span>
						</li>
						<li>
							<van-icon name="logistics" class="listicon" />
							<span>已发货</span>
						</li>
						<li>
							<van-icon name="comment-o" class="listicon" />
							<span>待评论</span>
						</li>
						<li>
							<van-icon name="after-sale" class="listicon" />
							<span>退换/售后</span>
						</li>
					</ul>
				</div>
			</div>
			<div class="mid">
				<div class="title">
					<span>常用工具</span>
				</div>
				<ul>
					<li v-for="(item,index) in grid" :key="index">
						<img :src="item.url" alt="">
						<div>{{item.title}}</div>
					</li>
				</ul>
			</div>
		</div>
		<!-- 订单与常用工具栏 end -->
		
		<div class="mainad"></div>
		
		<!-- 底部 start -->
		<div class="footer">
			  <div>
				  <ul class="footertop">
					  <li>
						  <i class="iconfont icon-shouji"></i>下载App
					  </li>
					  <li>
						  <i class="iconfont icon-denglu"></i>
						  <span v-if="!$store.state.userInfo.M_LoginID" @click="$router.push('/login')">登录账号</span>
						  <span v-else @click="logout()">退出登录</span>
					  </li>
				  </ul>
				  <div class="footerbottom">
					  <ul>
						  <li>营业执照</li>
						  <li></li>
						  <li>隐私政策</li>
						  <li></li>
						  <li>用户协议</li>
					  </ul>
					  <div>
						  ©2005 - 2022 OPPO 版权所有 粤ICP备14056724号
					  </div>
				  </div>
			  </div>
		</div>
		<!-- 底部 end -->
	</div>
</template>

<script>
// 获取常用工具接口
import { GetCate } from '@/api/cate/cate.js'
// 退出登录接口
import { Login } from '@/api/user/user.js'
export default{
	data(){
		return{
			grid:[]
		}
	},
	methods:{
		
		// 获取常用工具
		getGrid(){
			GetCate(
			'/cn/oapi/goods/web/products/040401',
			{loadings:1}
			).then(res=>{
				this.grid=res.data.data[0].productDetailss
			})
		},
		
		// 退出登录
		logout(){
			Login({dopost:'exit'})
			.then(res=>{
				if(res.data.status==1){
					this.$toast(res.data.msg)
					window.localStorage.removeItem('isLog')
					this.$store.dispatch('getUserInfo')
				}else{
					this.$notify(res.data.msg)
				}
			})
		}

	},
	created(){
		this.getGrid()
		this.$store.dispatch('getUserInfo')
	}
}
</script>

<style scoped="scoped">
	.mainad{
		height: .24rem;
		background-color: #f7f8fa;
	}
	.user{
		background: url(../../assets/bg.png) #fff no-repeat top;
		background-size: 100% auto;
	}
	.header{
		width: 100%;
		height: 3.22rem;
		padding: 0 0.24rem;
	}
	.header .myuser{
		height: 2.08rem;
		padding: 0.42rem 0;
		display: flex;
		align-items: center;
	}
	.header .myuser .userimg{
		width: 1.24rem;
		height: 1.24rem;
		margin-right: 0.18rem;
		overflow: hidden;
		border-radius: 50%;
	}
	.header .myuser .userimg img{
		width: 100%;
		height: 100%;
	}
	.header .myuser .usercontainer{
		flex: 1;
	}
	.header .myuser .usercontainer .username{
		width: 4.32rem;
		height: 0.34rem;
		line-height: .34rem;
		color: #333;
		font-weight: 500;
		font-size: .34rem;
		overflow: hidden;
	}
	.header .myuser .usercontainer .userid{
		width: 4.32rem;
		font-size: 0.26rem;
		color: #666;
		margin-top: 0.16rem;
		overflow: hidden;
	}
	.header .myuser>button{
		min-width: 1.28rem;
		height: 0.5rem;
		font-size: .28rem;
		border-radius: 2em;
		color: #fff;
		background-color: #f63434;
		border: none;
	}
	.header .header-property{
		display: flex;
		/* justify-content: space-between; */
	}
	.header .header-property>div{
		width: 33.3333%;
		text-align: center;
		font-size: .26rem;
	}
	.header .header-property .property-value{
		font-size: .3rem;
		margin-bottom: .23rem;
		font-weight: 500;
	}
	.main{
		padding-bottom: 0.16rem;
	}
	.main .top .title{
		display: flex;
		justify-content: space-between;
		line-height: .46rem;
		padding: .24rem;
		color: #000;
		font-weight: 500;
		font-size: .3rem;
	}
	.main .top .title .last{
		font-size: .26rem;
		color: #666;
	}
	.main .top .list{
		margin: 0 0 .15rem;
		text-align: center;
		padding: 0 0.24rem;
	}
	.main .top .list .listicon{
		font-size: .58rem;
		margin-top: .14rem;
	}
	.main .top .list ul{
		display: flex;
		height: 1.28rem;
		color: #666;
	}
	.main .top .list ul li{
		display: flex;
		width: 20%;
		flex-direction: column;
	}
	.main .top .list ul li span{
		font-size: .26rem;
		margin-top: .16rem;
	}
	.main .mid{
		padding-bottom: .3rem;
	}
	.main .mid .title{
		line-height: .46rem;
		padding: .24rem;
		margin-top: .2rem;
		color: #000;
		font-weight: 500;
		font-size: .3rem;
	}
	.main .mid ul{
		display: flex;
		flex-wrap: wrap;
		padding: 0 .24rem;
	}
	.main .mid ul li{
		padding: .2rem .12rem 0;
		display: flex;
		flex-direction: column;
		/* justify-content: center; */
		align-items: center;
		text-align: center;
	}
	.main .mid ul li img{
		width: .62rem;
		height: .62rem;
	}
	.main .mid ul li div{
		width: 1.515rem;
		line-height: .32rem;
		font-size: .26rem;
		margin-top: .12rem;
	}
	.footer .footertop{
		width: 100%;
		display: flex;
		font-size: .26rem;
		text-align: center;
		height: .82rem;
		line-height: .82rem;
		color: #333;
	}
	.footer .footertop li{
		width: 50%;
		display: flex;
		justify-content: center;
	}
	.footer .footertop i{
		font-size: .42rem;
		z-index: 9999;
		color: #b2b2b2;
	}
	.footer .footerbottom{
		width: 100%;
		font-size: .2rem;
		color: #666;
		height: 1.41rem;
		display: flex;
		/* align-items: center; */
		flex-direction: column;
		justify-content: center;
		align-items: center;
		text-align: center;
	}
	.footer .footerbottom ul{
		display: flex;
		justify-content: space-between;
		width: 3.76rem;
		margin-bottom: .2rem;
	}
</style>
