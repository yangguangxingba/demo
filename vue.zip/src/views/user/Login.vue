<template>
	<div>
		
		<!-- 顶部返回栏 start -->
		<van-nav-bar
		  left-text="返回"
		  left-arrow
		  @click-left="$router.back()"
		  class="navbar"
		/>
		<!-- 顶部返回栏 end -->
		
		<!-- Logo栏 start -->
		<div class="logo">
			<img src="../../assets/oppolog.png" alt="">
			<p>登录欢太账号可享受更多的服务</p>
		</div>
		<!-- Logo栏 end -->
		
		<!-- 主体登录栏 start -->
		<div class="main">
			<p><input type="text" v-model="user.userid" placeholder="请输入用户名" /></p>
			<p><input type="password" v-model="user.pwd" placeholder="请输入密码" /></p>
			<div class="yanz"><input type="number" v-model="userCode" placeholder="请输入验证码"><button type="button" @click="yanzm()">获取验证码</button></div>
			<button type="button" @click="login" :disabled="!(user.userid&&user.pwd)" :class="{'weightcolor':user.userid&&user.pwd}">登录</button>
			<p class="goreg" @click="$router.push('/register')">注册账号</p>
		</div>
		<!-- 主体登录栏 end -->
	</div>
</template>

<script>
	// 引入登录接口
	import { Login } from '@/api/user/user.js'
	export default {
		data(){
			return{
				user:{
					fmdo:'login',
					dopost:'login',
					userid:'',
					pwd:''
				},
				randoms:-9,
				userCode:''
			}
		},
		methods:{
			// 获取验证码
			yanzm(){
				this.randoms=parseInt(Math.random()*9000)+1000
				this.$notify(`验证码:${this.randoms}`);
			},
			// 登录
			login(){
				Login(this.user,{loadings:1})
				.then(res=>{
					// 提醒弹窗
					if(this.userCode==this.randoms){
						if(res.data.status==1){
						this.$toast(res.data.msg)
						window.localStorage.setItem('isLog','true')
						// 登录成功 跳转
						var froms=this.$route.query.froms||'/user'
						this.$router.replace(froms)
						}else{
							this.$notify(res.data.msg)
						}
					}else{
						this.$notify('验证码错误')
					}
				}).catch(err=>{
					console.log(err)
				})
			}
		}
	}
</script>

<style>
	.van-nav-bar__content{
		height: .81rem;
		font-size: .36rem;
		line-height: .81rem;
	}
	.van-nav-bar__content .van-nav-bar__left{
		font-size: .3rem;
	}
	.van-nav-bar__content .van-nav-bar__left .van-icon{
		font-size: .3rem;
		color: #f63434;
	}
	.van-nav-bar__content .van-nav-bar__left .van-nav-bar__text{
		color: #f63434;
	}
	.van-nav-bar__content .van-ellipsis{
		color: #f63434;
		font-size: .46rem;
	}
</style>

<style scoped="scoped">
	.main .yanz{
		display: flex;
		align-items: center;
		margin-bottom: .6rem;
	}
	.main .yanz>input{
		flex: 2;
		margin-bottom: 0;
	}
	.main .yanz>button{
		margin-left: .2rem;
		flex: 1;
		font-size: .24rem;
		height: .8rem;
		opacity: .8;
	}
	.main .weightcolor{
		opacity: 1;
	}
	.logo{
		padding: .4rem 0 .6rem;
		text-align: center;
		font-size: .24rem;
		font-weight: 500;
	}
	.logo img{
		width: 3.25rem;
		/* height: ; */
		margin: .3rem 0 .3rem;
	}
	.main{
		width: 100%;
		padding: 0.5rem 0.66rem 0;
	}
	.main input{
		border-radius: 0.2rem;
		width: 100%;
		height: 1rem;
		padding: 0.35rem 0.42rem;
		font-size: .3rem;
		line-height: 1rem;
		border: none;
		background-color: #f7f7f7;
		margin-bottom: .2rem;
	}
	.main button{
		background-color: #2ad181;
		opacity: .3;
		border: none;
		width: 100%;
		border-radius: .28rem;
		font-size: .3rem;
		color: #fff;
		height: 1rem;
	}
	.main .goreg{
		padding-top: .5rem;
		text-align: center;
		color: #2ad181;
		font-size: .3rem;
		opacity: .75;
	}
</style>
