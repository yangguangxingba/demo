<template>
	<div>
		<!-- 顶部返回栏 start -->
		<van-nav-bar
		  left-text="返回"
		  left-arrow
		  @click-left="$router.back()"
		  class="navbar"
		/>
		<!-- 顶部返回栏 end -->
		
		<!-- 中间注册栏 start -->
		<div class="main">
			<h1>注册账号</h1>
			<p><input type="text" v-model="user.userid" placeholder="请输入用户名" /></p>
			<p><input type="email" v-model="user.email" placeholder="请输入邮箱" /></p>
			<p><input type="password" v-model="user.userpwd" placeholder="请输入密码" /></p>
			<button type="button" @click="register" :disabled="!(user.userid&&user.email&&user.userpwd)" :class="{'weightcolor':user.userid&&user.email&&user.userpwd}">注册</button>
		</div>
		<!-- 中间注册栏 end -->
		
		<!-- 底部版权栏 start -->
		<div class="footer">
			<p>© 2005 - 2021 广东欢太 版权所有 粤ICP备 14056724 号-2&emsp;联系方式：4001-999-666</p>
		</div>
		<!-- 底部版权栏 end -->
		
	</div>
</template>
    
<script>
	import { Register } from '@/api/user/user.js'
	export default {
		data(){
			return{
				user:{
					userid:'',
					email:'',
					userpwd:''
				}
			}
		},
		methods:{
			// 注册
			register(){
				Register(this.user)
				.then(res=>{
					console.log(res)
					if(res.data.status==1){
						// 注册成功 跳转
						this.$toast(res.data.msg)
						this.$router.replace('/login')
					}else{
						this.$notify(res.data.msg)
					}
				}).catch(err=>{
					console.log(err)
				})
			}
		}
	}
</script>

<style>
	.van-nav-bar__content{
		height: .81rem;
		font-size: .36rem;
		line-height: .81rem;
		margin-left: 0.1rem;
	}
	.van-nav-bar__content .van-nav-bar__left{
		font-size: .3rem;
	}
	.van-nav-bar__content .van-nav-bar__left .van-icon{
		font-size: .3rem;
		color: #f63434;
	}
	.van-nav-bar__content .van-nav-bar__left .van-nav-bar__text{
		color: #f63434;
	}
	.van-nav-bar__content .van-ellipsis{
		color: #f63434;
		font-size: .46rem;
	}
</style>
<style scoped="scoped">
	.main .weightcolor{
		opacity: 1;
	}
	.main{
		width: 100%;
		padding: 0.5rem 0.66rem 0;
	}
	.main h1{
		padding: 0rem 0 .5rem;
		font-size: .7rem;
		line-height: 1rem;
		font-weight: 500;
		text-align: center;
		font-size: .52rem;
	}
	.main input{
		border-radius: 0.2rem;
		width: 100%;
		height: 1rem;
		padding: 0.35rem 0.42rem;
		font-size: .3rem;
		line-height: 1rem;
		border: none;
		background-color: #f7f7f7;
		margin-bottom: .2rem;
	}
	.main button{
		background-color: #2ad181;
		opacity: .3;
		border: none;
		width: 100%;
		border-radius: .28rem;
		font-size: .3rem;
		color: #fff;
		height: 1rem;
	}
	.footer p{
		font-size: .24rem;
		color: #9b9b9b;
		padding: .83333rem .66667rem;
		text-align: center;
	}
</style>