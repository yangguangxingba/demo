<template>
	<div>
		<!-- 顶部导航栏 start -->
		<div class="header">
			<van-icon name="arrow-left" @click="$router.back()"/>
			购物车
		</div>
		<!-- 顶部导航栏 end -->
		
		<!-- 主体部分 start -->
		<div class="main">
			
			<!-- 空购物车状态 start -->
			<div class="maintop" v-if="$store.state.goods.length==0">
				<img src="../assets/carttop.png" alt="">
				<div class="maintop-text">购物车还没有商品</div>
				<button @click="$router.replace('/cate')">去逛逛</button>
			</div>
			<!-- 空购物车状态 end -->
			
			<!-- 购物车商品渲染 start -->
			<div v-else class="carts">
				<ul>
					<li v-for="(item,index) in $store.state.goods" :key="index">
						<van-checkbox v-model="item.checked" checked-color="#ee0a24" @change="revers"></van-checkbox>
						<div class="imgs"><img :src="item.url" alt="" width="100%"></div>
						<div class="itemtitle">
							<div class="itemname">{{item.name}}</div>
							<div class="itemprice">
								<span>¥{{item.price}}</span>
								<van-stepper v-model="item.shuliang" theme="round" button-size="35" disable-input />
								<button type="button" @click="delCart(item)">移除</button>
							</div>
						</div>
					</li>
				</ul>
			</div>
			<!-- 购物车商品渲染 end -->
			
			<!-- 底部提交栏（vant组件） start -->
			<van-submit-bar :price="$store.getters.totalPrice*100" button-text="提交订单" @submit="onSubmit" v-if="!$store.state.goods.length==0">
			  <van-checkbox v-model="checked" @click="checkall">全选</van-checkbox>
			</van-submit-bar>
			<!-- 底部提交栏 end -->
			
		</div>
		<!-- 主体部分 end -->
	</div>
</template>

<script>
	
// 获取购物车数据接口
import { GetCart } from '@/api/cart/cart.js'

// 引入vuex中的mutations
import { mapMutations } from 'vuex'
export default{
	data(){
		return{
			checked:true,
		}
	},
	methods:{
		
		// 映射vuex中的mutations
		...mapMutations(['delCart']),
		
		// 实现购物车全选
		checkall(){
			this.$store.commit('checkAll',this.checked)
		},
		
		// 提交订单
		onSubmit(){},
		
		// 获取推荐商品数据
		getCart(){
			GetCart(
				'/cn/oapi/goods/web/recommend/product?position=cart&sectionId=cart_personalized&currentPage=1&pageSize=10&isRecommend=0'
			).then(res=>{
				console.log(res)
			})
		},
		
		// 购物车反选
		revers(){
			let arr = this.$store.state.goods.filter(item=>{
				return item.checked
			})
			if(arr.length==this.$store.state.goods.length){
				this.checked=true
			}else{
				this.checked=false
			}
		}
	},
	created(){
		this.getCart()
	}
}
</script>

<style>
	.van-icon-arrow-left {
		font-size: .46rem;
		line-height: .92rem;
		margin-left: .2rem;
		color: rgb(246, 52, 52);
		position: fixed;
		top: 0;
		left: -.2rem;
		z-index: 999;
	}
	.van-submit-bar{
		bottom: 1.1rem;
	}
	.van-checkbox__icon{
		font-size: .4rem;
	}
	.van-stepper__input{
		width: .5rem;
		font-size: .26rem;
	}
	.van-submit-bar__bar{
		height: .8rem;
		font-size: .26rem;
	}
	.van-submit-bar .van-checkbox{
		margin-left: .2rem;
	}
	.van-submit-bar__price{
		font-size: .3rem;
	}
	.van-submit-bar__button{
		width: 1.8rem;
		height: .6rem;
		font-size: .25rem;
	}
	.van-stepper__minus,.van-stepper__plus{
		width: .35rem !important;
		height: .35rem !important;
	}
</style>
<style scoped="scoped">
	.itemname{
		font-size: .3rem;
		color: #333;
		/* width: 4.12rem; */
		font-weight: 500;
		
	}
	.carts{
		padding: 0.32rem;
		z-index: 9999;
	}
	.carts ul li{
		display:flex;
		background-color:#fff;
		border-radius: 0.16rem;
		padding: 0.28rem 0.24rem;
		margin-bottom: .2rem;
		align-items: center;
		justify-content: center;
	}
	.carts .imgs{
		width:1.68rem;
		height:1.68rem;
		border-radius:.15rem;
		line-height: 1.68rem;
		text-align: center;
		flex:0 0 auto;
		background-color: #f7f8fa;
		margin-left: 0.2rem;
		margin-right: 0.16rem;
	}
	.carts .itemtitle{
		flex: 1;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		overflow: hidden;
		height: 1.6rem;
		
	}
	.carts .itemtitle .itemprice{
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.carts .itemtitle .itemprice button{
		border: none;
		background-color: #fff;
		font-size: .24rem;
	}
	.carts .itemtitle div span{
		font-size: .34rem;
		color: #f63434;
		font-weight: 500;
	}
	.header{
		width: 100%;
		height: .92rem;
		line-height: .92rem;
		text-align: center;
		font-size: .34rem;
		position: fixed;
		top: 0;
		left: 0;
		background-color: #fff;
		z-index: 9999;
	}
	.main{
		width: 100%;
		height: 100vh;
		padding-top: .92rem;
		padding-bottom: 1.1rem;
		background: #f7f8fa;
		position: fixed;
		top: 0;
		left: 0;
		overflow-y: scroll;
	}
	.main .maintop{
		margin-top: 0.72rem;
		text-align: center;
		font-size: .34rem;
		color: #acadae;
	}
	.main .maintop .maintop-text{
		margin: 0.3rem 0;
	}
	.main .maintop button{
		border: 1px solid rgba(0,0,0,.1);
		background-color: #fff;
		width: 2.04rem;
		height: .72rem;
		line-height: .72rem;
		border-radius: 2rem;
		font-size: .28rem;
		color: #f63434;
		margin-top: .32rem;
	}
	/* .main .recommend{
		margin-top: .3rem;
		font-size: .28rem;
	}
	.main .recommend .title{
		margin: ;
		text-align: center;
		margin: .3rem 0;
	} */
</style>
