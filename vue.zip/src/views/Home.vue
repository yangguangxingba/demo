<template>
	<div class="home" ref="hom">
		<!-- 顶部搜索栏 start -->
		<div class="header">
			<div class="search-box" @click="$router.push('/search')">
				<div class="search-icon"></div>
				<van-swipe style="height: 200px;" vertical :autoplay="3000">
					<van-swipe-item v-for="(item,index) in headertitle" :key="index">{{item.title}}</van-swipe-item>
				</van-swipe>
			</div>
		</div>
		<!-- 顶部搜索栏 end -->

		<!-- 轮播图 start -->
		<van-swipe class="my-swipe swipe" :autoplay="3000" indicator-color="white">
			<van-swipe-item v-for="(item,index) in swipe" :key="index"><img :src="item.url" alt=""></van-swipe-item>
		</van-swipe>
		<!-- 轮播图 end -->

		<!-- 中部导航 start -->
		<ul class="midnav">
			<li class="cates" v-for="(item,index) in cates" :key="index">
				<div class="catelogo">
					<img :src="item.url" alt="">
				</div>
				<div class="title">{{item.title}}</div>
			</li>
		</ul>
		<!-- 中部导航 end -->

		<!-- 主体部分 start -->
		<div class="home-contain">

			<!-- 推荐商品 start -->
			<div class="contain-one">
				<img :src="item.url" v-for="(item,index) in mains[0].productDetailss" :key="index"
					:class="{minImg:index>7}">
			</div>
			<!-- 推荐商品 end -->

			<!-- 今日必抢 start -->
			<div class="contain-two">
				<!-- 今日必抢 - 顶部 -->
				<div class="contain-two-top">
					<span class="contain-two-title">
						{{mains[1].name}}
					</span>
					<span class="time">
						<van-count-down :time="time" class="time" />
					</span>
					<span>
						后结束
					</span>
					<span class="more-text">
						更多>
					</span>
				</div>
				<!-- 今日必抢 - 商品信息 -->
				<div class="contain-two-bottom">
					<ul class="contain-two-list">
						<li v-for="(item,index) in mains[1].productDetailss" :key="index">
							<div class="imglist">
								<img :src="item.url" alt="">
							</div>
							<div class="title">
								{{item.title}}
							</div>
							<div class="price">
								<div>¥{{item.price}}</div>
								<div>¥{{item.originalPrice}}</div>
							</div>
						</li>
						<li class="last">
							<div>
								<div class="more">
									更多<br>产品
								</div>
								<div class="moreimg">
									<img src="../assets/right.png" alt="">
								</div>
							</div>
						</li>
					</ul>
				</div>

			</div>
			<!-- 今日必抢 end -->

			<!-- 手机专区 <————> 更多好物 start -->
			<div class="mainstay">
				<div v-for="(item,index) in mainstay" :key="index">
					<div class="title">{{item.name}}</div>
					<div v-if="item.url" class="bigimg">
						<img :src="item.url" alt="">
					</div>
					<div class="lists">
						<div v-for="(item,index) in item.productDetailss" :key="index">
							<img :src="item.url" alt="" width="100%">
							<div class="text-title">
								{{item.title}}<br>
							</div>
							<div class="listprice">
								<span>¥{{item.price}}</span>
								<span v-if="item.originalPrice" class="lastspan">¥{{item.originalPrice}}</span>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- 手机专区 <————> 更多好物 end -->


		</div>
		<!-- 主体部分 end -->

		<!-- 底部 start -->
		<div class="footer">
			<div>
				<ul class="footertop">
					<li>
						<i class="iconfont icon-shouji"></i>下载App
					</li>
					<li>
						<i class="iconfont icon-denglu"></i>
						<span v-if="!$store.state.userInfo.M_LoginID" @click="$router.push('/login')">登录账号</span>
						<span v-else @click="logout()">退出登录</span>
					</li>
				</ul>
				<div class="footerbottom">
					<ul>
						<li>营业执照</li>
						<li></li>
						<li>隐私政策</li>
						<li></li>
						<li>用户协议</li>
					</ul>
					<div>
						©2005 - 2022 OPPO 版权所有 粤ICP备14056724号
					</div>
				</div>
			</div>
		</div>
		<!-- 底部 end -->

		<!-- 侧边栏 start -->
		<div class="homeright" v-show="scolltop>600">
			<div>
				<i class="iconfont icon-24gl-headset"></i>
			</div>
			<div @click="toTop()">
				<i class="iconfont icon-huidaodingbu"></i>
			</div>
		</div>
		<!-- 侧边栏 end -->
	</div>
</template>

<script>
	// 获取首页内容
	import { GetHome } from '@/api/home/home.js'
	// 退出登录接口
	import { Login } from '@/api/user/user.js'
	
	export default {
		data() {
			return {
				swipe: [],
				cates: [],
				mains: [],
				time: 0,
				mainstay: [],
				scolltop: 0,
				headertitle: []
			}
		},
		methods: {
			
			// 获取轮播图数据
			getHome() {
				GetHome(
					"/cn/oapi/configs/web/banners/040101,040201",
				).then(res => {
					this.swipe = res.data.data
				})
			},
			
			// 获取中部导航数据
			getNav() {
				GetHome(
					"/cn/oapi/configs/web/icons/040202,040203",
				).then(res => {
					this.cates = res.data.data
				})
			},
			
			// 获取主体商品数据
			getMain() {
				GetHome(
					"cn/oapi/goods/web/products/v15/040204",
				).then(res => {
					this.mains = res.data.data
					this.mainstay = res.data.data.slice(2)
					this.time = res.data.data[1].endAt - res.data.data[1].beginAt
				}).catch(err => {
					console.log(err)
				})
			},
			
			// 回到顶部
			toTop() {
				var times = setInterval(() => {
					if (this.scolltop <= 0) {
						clearInterval(times)
					}
					this.scolltop -= 100
					document.documentElement.scrollTop = this.scolltop
				}, 10)
			},
			
			// 获取搜索栏文字
			getheadertitle() {
				GetHome(
					"cn/oapi/configs/web/icons/040109",
				).then(res => {
					this.headertitle = res.data.data
				}).catch(err => {
					console.log(err)
				})
			},
			
			// 退出登录
			logout() {
				Login({
						dopost: 'exit'
					})
					.then(res => {
						if (res.data.status == 1) {
							this.userInfo = {}
							this.$toast(res.data.msg)
							window.localStorage.removeItem('isLog')
							this.$store.dispatch('getUserInfo')
						}
					})
			}
		},
		created() {
			this.getHome()
			this.getNav()
			this.getMain()
			this.$store.dispatch('getUserInfo')
			this.getheadertitle()
		},
		mounted() {

			window.onscroll = () => {
				this.scolltop = document.documentElement.scrollTop
			}
			
		}
	}
</script>

<style>
	.van-swipe__track .van-swipe-item {
		color: #b2b2b2;
		font-weight: 400;
		font-size: .26rem;
		white-space: nowrap;
		text-overflow: ellipsis;
		line-height: .66rem;
	}
	.van-popup{
		font-size: .24rem !important;
		line-height: .24rem !important;
	}
</style>

<style scoped="scoped">
	

	.header {
		height: .92rem;
		width: 100%;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.header .search-box {
		width: 6.88rem;
		height: .66rem;
		background-color: #f7f8fa;
		border-radius: .09rem;
		display: flex;
		/* justify-content: center; */
		/* align-items: center; */
	}

	.header .search-box .search-icon:before {
		content: "";
		display: block;
		width: .66rem;
		height: .66rem;
		background-repeat: no-repeat;
		background-size: 100%;
	}

	.header .search-box .search-icon:before {
		background-image: url(../assets/search.png);
	}

	.swipe {
		height: 3.25rem;
		width: 100%;
		position: relative;
	}

	.swipe img {
		width: 100%;
		position: absolute;
		bottom: 0;
	}

	.midnav {
		width: 100%;
		height: 1.98rem;
		display: flex;
		padding-bottom: .45rem;
	}

	.midnav .cates {
		width: 20%;
		justify-content: center;
		align-items: center;
		flex-wrap: wrap;
		text-align: center;
	}

	.midnav .cates .catelogo {
		height: .9rem;
		margin-top: .25rem;
	}

	.midnav .cates .catelogo img {
		width: .9rem;
		height: .9rem;
	}

	.midnav .cates .title {
		margin-top: .1rem;
		color: rgba(0, 0, 0, .6);
		font-weight: 400;
		font-size: .24rem;
	}

	.home-contain {
		background-color: #f7f8fa;
	}

	.home-contain .contain-one {
		width: 100%;
		padding: .24rem;
		padding-bottom: .28rem;
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		background: #f7f8fa;
	}

	.home-contain .contain-one img {
		/* width: 3.43rem; */
		width: 49%;
		/* height: 2.14rem; */
		margin-bottom: .16rem;
	}

	.home-contain .contain-one .minImg {
		/* width: 1.635rem; */
		width: 23%;
		margin-bottom: 0rem;
	}

	.home-contain .contain-two {
		width: 100%;
		/* overflow: auto; */
		padding: .24rem 0;
		background-color: #f7f8fa;
	}

	.home-contain .contain-two .contain-two-top {
		margin: 0 .24rem .14rem;
		font-size: .26rem;
		color: rgba(0, 0, 0, .3);
		position: relative;
		height: .6rem;
		line-height: .6rem;
	}

	.home-contain .contain-two .contain-two-title {
		font-size: 0.3rem;
		color: #000;
	}

	.home-contain .contain-two .time {
		display: inline-block;
		color: #f63434;
		font-size: .26rem;
		letter-spacing: .03rem;

	}

	.home-contain .contain-two .more-text {
		position: absolute;
		right: 0;
	}

	.home-contain .contain-two .contain-two-bottom {
		overflow-x: scroll;
		width: 7.02rem;
		margin: 0 auto;
		border-radius: 0.16rem;
		z-index: 999;
		background-color: #FFFFFF;
	}

	.contain-two-bottom::-webkit-scrollbar {
		width: 0 !important
	}

	.home-contain .contain-two .contain-two-list {
		display: flex;
		flex-direction: row;
		align-items: center;
	}

	.home-contain .contain-two .contain-two-list>li {
		background-color: #fff;
		width: 2.08rem;
		height: 2.98rem;
		display: flex;
		flex-wrap: wrap;
		flex-direction: column;
		align-items: center;
	}

	.home-contain .contain-two .contain-two-list>li:last-of-type>div {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		width: 1.39rem;
		height: 2.31rem;
		border: 1px solid #e4e4e4;
		border-radius: 0.11rem;
		margin: 0 0.23rem;
	}

	.home-contain .contain-two .contain-two-list .imglist {
		position: relative;
		width: 1.84rem;
		height: 1.84rem;
		margin-top: 0.12rem;
	}

	.home-contain .contain-two .contain-two-list .last {
		justify-content: center;
	}

	.home-contain .contain-two .contain-two-list .last .more {
		width: 0.59rem;
		color: #999;
		font-weight: 400;
		font-size: .25rem;
		line-height: 1.2;
	}

	.home-contain .contain-two .contain-two-list .last .moreimg {
		width: 0.46rem;
		height: 0.46rem;
		margin-top: 0.14rem;
		font-size: 0;
	}

	.home-contain .contain-two .contain-two-list .last .moreimg img {
		width: 100%;
	}

	.home-contain .contain-two .imglist img {
		width: 100%;
	}

	.home-contain .contain-two .title {
		width: 100%;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
		text-align: center;
		font-size: .26rem;
		margin: 0.1rem 0 0.05rem;
	}

	.home-contain .contain-two .price {
		display: flex;
		justify-content: center;
		align-items: center;
		color: #f63434;
		font-weight: 500;
		font-size: .26rem;
	}

	.home-contain .contain-two .price>div:last-of-type {
		margin-left: 0.06rem;
		color: rgba(0, 0, 0, .3);
		font-size: .22rem;
		text-decoration: line-through;
	}

	.home-contain .mainstay {
		background-color: #f7f8fa;
	}

	.home-contain .mainstay>div {
		padding: 0.24rem 0.24rem 0;

	}

	.home-contain .mainstay .title {
		height: 0.6rem;
		margin-bottom: 0.14rem;
		color: #000;
		font-weight: 500;
		font-size: .3rem;
		line-height: .6rem;
	}

	.home-contain .mainstay .bigimg img {
		width: 100%;
		border-radius: 0.16rem;
	}

	.home-contain .mainstay .lists {
		display: flex;
		flex-wrap: wrap;
		font-size: .26rem;
		border-radius: 0.16rem;
		margin-top: 0.12rem;
		justify-content: space-between;
	}

	.home-contain .mainstay .lists>div {
		width: 33%;
		margin-top: .5%;
		padding-bottom: 0.3rem;
		background-color: #FFFFFF;
		display: flex;
		flex-wrap: wrap;
		justify-content: top;
		align-items: center;
		flex-direction: column;

	}

	.home-contain .mainstay .lists .text-title {
		padding: 0px 0.17rem;
		line-height: .39rem;
		font-weight: 400;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
		overflow: hidden;

	}

	.home-contain .mainstay .lists .listprice {
		text-align: left;
		padding: 0px 0.17rem;
		width: 100%;
		display: flex;
		justify-content: flex-start;
		font-size: .26rem;
		color: #f63434;
		align-items: center;
		margin-top: 0.12rem;
	}

	.home-contain .mainstay .lists .listprice .lastspan {
		margin-left: 0.06rem;
		color: rgba(0, 0, 0, .3);
		font-weight: 400;
		font-size: .21rem;
		text-decoration: line-through;

	}

	.home-contain::after {
		display: block;
		content: "";
		width: 100%;
		height: .48rem;
		background-color: #f7f8fa;
	}

	.footer .footertop {
		width: 100%;
		display: flex;
		font-size: .26rem;
		text-align: center;
		height: .82rem;
		line-height: .82rem;
		color: #333;
	}

	.footer .footertop li {
		width: 50%;
		display: flex;
		justify-content: center;
	}

	.footer .footertop i {
		font-size: .42rem;
		z-index: 9999;
		color: #b2b2b2;
	}

	.footer .footerbottom {
		width: 100%;
		font-size: .2rem;
		color: #666;
		height: 1.41rem;
		display: flex;
		/* align-items: center; */
		flex-direction: column;
		justify-content: center;
		align-items: center;
		text-align: center;
	}

	.footer .footerbottom ul {
		display: flex;
		justify-content: space-between;
		width: 3.76rem;
		margin-bottom: .2rem;
	}

	.homeright {
		position: fixed;
		right: .24rem;
		top: 56%;
	}

	.homeright div {
		width: .74rem;
		height: .74rem;
		text-align: center;
		background: #fff;
		border-radius: 0.15rem;
		box-shadow: 1px 1px 1px -1px #c8c7cc;
		margin-top: 0.16rem;
		line-height: .74rem;
	}

	.homeright div i {
		font-size: .42rem;
		font-weight: 900;
	}
</style>
