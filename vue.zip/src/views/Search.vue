<template>
	<div class="searchMain">
		
		<!-- 顶部搜索栏 start -->
		<div class="search">
			<van-icon name="arrow-left" @click="$router.back()" />
			<van-search
			  v-model="value"
			  show-action
			  placeholder="请输入搜索商品"
			  @search="onSearch"
			>
			  <template #action>
			    <div @click="onSearch">搜索</div>
			  </template>
			</van-search>
		</div>
		<!-- 顶部搜索栏 end -->
		
		<!-- 热门推荐栏 start -->
		<div class="goodsearch">
			<div class="hottitle">
				热门推荐
			</div>
			<div>
				<span v-for="(item,index) in headertitle" :key="index">{{item.title}}</span>
			</div>
		</div>
		<!-- 热门推荐栏 end -->
	</div>
</template>

<script>
	// 获取推荐商品数据接口
	import { GetHome } from '@/api/home/home.js'
	// 获取各分类数据接口
	import { GetCate } from '@/api/cate/cate.js'
	export default{
		data(){
			return{
				value:'',
				headertitle:[],
				mainlist:[]
			}
		},
		methods:{
			
			// 搜索并跳转
			onSearch(){
				this.mainlist[0].category.goods.forEach(item=>{
					if(item.spuName.includes(this.value)){
						this.$router.push(/details/+item.skuId)
					}
				})
			},
			
			// 热门推荐商品数据
			getheadertitle() {
				GetHome(
					"cn/oapi/configs/web/icons/040109",
				).then(res => {
					this.headertitle = res.data.data
				}).catch(err => {
					console.log(err)
				})
			},
			
			// 获取各分类商品数据
			getList(id){
				GetCate(
					'/cn/oapi/goods-business/category/first/detail?code='+id+'&scene=mall&preview=false',
				).then(res=>{
					this.mainlist=res.data.data
				})
			}
		},
		mounted(){
			this.getheadertitle()
			this.getList("000024")
		}
	}
</script>

<style scoped="scoped">
	.searchMain .search{
		display: flex;
		align-items: center;
		height: .92rem;
		flex-wrap: wrap;
	}
	.searchMain .search .van-search{
		flex: 1;
		padding: 0;
	}
	.searchMain .search .van-search .van-cell{
		align-items: center;
		font-size: .26rem;
	}
	.searchMain .search .van-search .van-search__action{
		font-size: .26rem;
	}
	.searchMain .search .van-search__content{
		border-radius: 0.09rem;
		height: .66rem;
		
	}
	.searchMain .search .van-icon{
		font-size: .5rem;
		margin: 0 .1rem;
		z-index: 9999;
	}
	.searchMain .goodsearch{
		padding: .62rem .24rem 0;
	}
	.searchMain .goodsearch .hottitle{
		margin-bottom: .36rem;
		color: #999;
		font-weight: 400;
		font-size: .26rem;
	}
	.searchMain .goodsearch span{
		display: inline-block;
		margin-right: 0.16rem;
		margin-bottom: 0.16rem;
		padding: 0.04rem 0.2rem;
		font-weight: 400;
		font-size: .26rem;
		line-height: .62rem;
		border-radius: 0.1rem;
		color: #fff;
		background: linear-gradient(
		228deg
		,#ff4343,#ff8243);
	}
</style>
