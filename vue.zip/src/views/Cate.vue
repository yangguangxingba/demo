<template>
  <div>
	  <!-- 顶部搜索栏 start -->
	  <div class="header">
		  <div class="search-box" @click="$router.push('/search')">
		  		<div class="search-icon"></div>
		  </div>
	  </div>
	  <!-- 顶部搜索栏 end -->
	  
	  <!-- 主体部分 start -->
	  <div class="main">
		  
		  <!-- 左侧分类栏 start -->
		  <div class="mainleft">
			  <ul>
				  <li v-for="(item,index) in mains" :key="index" @click="getList(item.categoryCode),cateCurrent=index" :class="{'cate_active':cateCurrent == index}">{{item.name}}</li>
			  </ul>
		  </div>
		  <!-- 左侧分类栏 end -->
		  
		  <!-- 右侧商品详情 start -->
		  <div class="mainright">
			  <ul>
				  <li v-for="(item,index) in mainlist" :key="index" class="rightlist">
					  <div v-if="item.category.ads.length!=0"><img :src="item.category.ads[0].logoUrl" class="firstlogo"></div>
					  <div class="rightlist-goods">
						  <h4>{{item.category.name}}</h4>
						  <ul>
							  <li v-for="(item,index) in item.category.goods" :key="index" class="oks" @click="$router.push('/details/'+item.skuId)">
								  <div class="mainImg">
									  <img :src="item.mainImg" alt="">
								  </div>
								  <div class="mainInfo">
									  <p>{{item.spuName}}</p>
									  <p>{{item.marketingText}}</p>
									  <div>
										   <span>¥{{item.price.price}}</span>
										   <span class="originalPrice" v-if="item.price.originalPrice">¥{{item.price.originalPrice}}</span>
									  </div>
									 
								  </div>
							  </li>
							  
							  <!-- 配件详情 start -->
							  <li v-if="item.child">
								  <ul class="child">
									  <li v-for="(item,index) in item.child" :key="index"  @click="getitem(item.category.secondLevelCode)">
										  <div>
											  <img :src="item.category.logo.secondaryPic" alt="">
										  </div>
										  <h5>{{item.category.name}}</h5>
									  </li>
								  </ul>
							  </li>
							  <!-- 配件详情 end -->
							  
						  </ul>
					  </div>
					  
				  </li>
			  </ul>
		  </div>
		    <!-- 右侧商品详情 end -->
	  </div>
	  <!-- 主体部分 end -->
  </div>
</template>

<script>
// 获取分类数据
import { GetCate } from '@/api/cate/cate.js'
export default{
	data(){
		return{
			mains:[],
			cateCurrent:0,
			mainlist:[]
		}
	},
	methods:{
		// 获取左侧分类栏数据
		getCate(){
			GetCate(
			'/cn/oapi/goods-business/category/first?scene=mall&preview=false'
			).then(res=>{
				this.mains=res.data.data
			})
		},
		// 获取各个分类的商品数据
		getList(id){
			GetCate(
				'/cn/oapi/goods-business/category/first/detail?code='+id+'&scene=mall&preview=false',
			).then(res=>{
				this.mainlist=res.data.data
			})
		},
		// 点击获取配件
		getitem(item){
			console.log(item)
		}
	},
	created(){
		this.getCate()
		this.getList("000024")
	}
}
</script>

<style scoped="scoped">
	.header{
			height: .92rem;
			width: 100%;
			display: flex;
			justify-content: center;
			align-items: center;
			border-bottom: 0.01rem solid #e5e5e5;
			position: fixed;
			top: 0;
			left: 0;
	}
	.header .search-box{
			width: 6.88rem;
			height: .66rem;
			background-color: #f7f8fa;
			border-radius: .09rem;
	}
	.header .search-box .search-icon:before{
			content: "";
			display: block;
			width: .66rem;
			height: .66rem;
			background-repeat: no-repeat;
			background-size: 100%;
	}
	.header .search-box .search-icon:before{background-image: url(../assets/search.png);}
	.main{
		width: 100%;
		height: 100vh;
		display: flex;
		padding-bottom: 2.02rem;
		position: fixed;
		top: .92rem;
		left: 0;
	}
	.main .mainleft{
		width: 1.88rem;
		height: 100%;
		font-size: 0.28rem;
		color: #00000099;
		overflow-y: scroll;
	}
	.main .mainleft::-webkit-scrollbar { width: 0 !important }
	.main .mainleft ul li{
		height: 1.06rem;
		line-height: 1.06rem;
		text-align: center;
	}
	.main .mainleft ul .cate_active{
		position: relative;
		color: #000;
		font-weight: 700;
		font-size: .3rem;
		transition: 1s;
	}
	.main .mainleft ul .cate_active::after{
		position: absolute;
		top: 0;
		bottom: 0;
		left: 0;
		width: 0.06rem;
		height: 0.3rem;
		margin: auto;
		background: #000;
		content: "";
	}
	.main .mainright{
		width: 5.62rem;
		height: 100%;
		font-size: .24rem;
		color: #000000D9;
		padding: 0.24rem;
		overflow-y: scroll;
	}
	.main .mainright>ul::-webkit-scrollbar { width: 0 !important }
	.main .mainright>ul{
		width: 100%;
		height: 100%;
		overflow-y: scroll;
	}
	.main .mainright .rightlist .firstlogo{
		width: 100%;
	}
	.main .mainright .rightlist .rightlist-goods{
		margin-top: 0.12rem;
	}
	.main .mainright .rightlist .rightlist-goods>h4{
		font-size: .3rem;
	    font-weight: 400;
	    line-height: .84rem;
	    padding-left: 0.16rem;
	    color: #000;
	}
	.main .mainright .rightlist .rightlist-goods>ul>.oks{
		display: flex;
		align-items: center;
		height: 1.52rem;
		margin-bottom: 0.16rem;
		background: #f8f8f8;
		border-radius: 0.25rem;
	}
	.main .mainright .rightlist .rightlist-goods .mainImg{
		width: 1.12rem;
		height: 1.12rem;
		margin: 0 0.2rem;
		text-align: center;
		line-height: 1.12rem;
	 }
	.main .mainright .rightlist .rightlist-goods .mainImg>img{
		  width: 100%;
	}
	.main .mainright .rightlist .rightlist-goods .mainInfo{
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		height: 1.12rem;
		color: rgba(0,0,0,.85);
		padding-right: 0.1rem;
		overflow: hidden;
	}
	.main .mainright .rightlist .rightlist-goods .mainInfo>p{
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
	}
	.main .mainright .rightlist .rightlist-goods .mainInfo>p:nth-of-type(2){
		color: rgba(0,0,0,.3);
	}
	.main .mainright .rightlist .rightlist-goods .mainInfo .originalPrice{
		margin-left: 0.1rem;
		color: rgba(0,0,0,.3);
		text-decoration: line-through;
	}
	.main .mainright .rightlist .rightlist-goods .child{
		display: flex;
		width: 100%;
		flex-wrap: wrap;
	}
	.main .mainright .rightlist .rightlist-goods .child li{
		padding-top: 0.2rem;
		width: 1.62rem;
		display: flex;
		flex-direction: column;
		align-items: center;
		font-size: .24rem;
		color: #333;
	}
	.main .mainright .rightlist .rightlist-goods .child li h5{
		font-size: .24rem;
		color: #333;
		font-weight: 400;
		margin-top: .1rem;
		text-align: center;
	}
	.main .mainright .rightlist .rightlist-goods .child li div{
		width: 1.02rem;
	}
	.main .mainright .rightlist .rightlist-goods .child li div img{
		width: 100%;
	}
</style>