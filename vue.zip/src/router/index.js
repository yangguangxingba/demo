import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/cate',
    name: 'Cate',
    component: () => import('../views/Cate.vue')
  },
  {
    path: '/cart',
    name: 'Cart',
    component: () => import('../views/Cart.vue'),
	meta:{
		requireAuth:true
	}
  },
  {
    path: '/details/:id',
    name: 'Details',
    component: () => import('../views/Details.vue'),
	meta:{
		nofoot:true
	}
  },
  {
    path: '/search',
    name: 'Search',
    component: () => import('../views/Search.vue'),
	meta:{
		nofoot:true
	}
  },
  {
    path: '/user',
    name: 'User',
    component: () => import('../views/user/User.vue')
  },
  {
    path: '/login',
    name: 'Login',
    component: ()=>import('../views/user/Login'),
	meta:{
		nofoot:true
	}
  },
  {
    path: '/register',
    name: 'Register',
    component: ()=>import('../views/user/Register'),
	meta:{
		nofoot:true
	}
  }
]

const router = new VueRouter({
  routes
})

// 路由守卫
router.beforeEach((to,from,next)=>{
	if(to.meta.requireAuth){
		if(window.localStorage.getItem('isLog')){
			next(true)
		}else{
			next('/login?froms='+to.path)
		}
	}else{
		next(true)
	}
})

export default router
