<template>
  <div id="app">
	<router-view class="page has-tabs"/>
    <div id="nav" v-if="!$route.meta.nofoot">
      <router-link to="/" class="nav-list ihome">首页</router-link>
      <router-link to="/cate" class="nav-list icate">分类</router-link>
      <router-link to="/cart" class="nav-list icart">
		  购物车
		  <van-badge v-if="$store.getters.totalNum" :content="$store.getters.totalNum" max="99" />
	  </router-link>
      <router-link to="/user" class="nav-list iuser">我的</router-link>
    </div>
  </div>
</template>

<style>
	.has-tabs{
		/* position: absolute;
		left: 0;
		top: 0; */
		padding-bottom: 1.1rem;
	}
	#app{
		height: 100vh;
		width: 100%;
		position: relative;
	}
	#nav{
		width: 100%;
		height: 1.1rem;
		display: flex;
		position: fixed;
		left: 0;
		bottom: 0;
		font-size: .2rem;
		text-align: center;
		background-color: #fff;
		z-index: 9999;
	}
	#nav .nav-list{
		color: rgba(0,0,0,.3);
		height: 1.1rem;
		width: 25%;
	}
	#nav .nav-list.router-link-exact-active{
		color: #f63434;
	}
	.nav-list:before{
		content: "";
		display: block;
		width: .48rem;
		height: .48rem;
		background-repeat: no-repeat;
		background-size: 100%;
		margin: .1rem auto;
	}
	.icart{
		position: relative;
	}
	.icart .van-badge{
		position: absolute;
		top: 0rem;
		right: .6rem;
		width: .32rem;
		height: .32rem;
		font-size: .24rem;
	}
	.nav-list.ihome:before{background-image: url(assets/home.png);}
	.nav-list.icate:before{background-image: url(assets/cate.png);}
	.nav-list.icart:before{background-image: url(assets/cart.png);}
	.nav-list.iuser:before{background-image: url(assets/user.png);}
	
	.nav-list.ihome.router-link-exact-active:before{background-image: url(assets/home-h.png);}
	.nav-list.icate.router-link-exact-active:before{background-image: url(assets/cate-h.png);}
	.nav-list.icart.router-link-exact-active:before{background-image: url(assets/cart-h.png);}
	.nav-list.iuser.router-link-exact-active:before{background-image: url(assets/user-h.png);}
</style>
