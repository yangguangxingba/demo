//存放分类模块 请求数据的方法 ANGLE_instanced_arrays

// 引入request  封装好的axios
import request from '@/utils/request.js'
import qs from 'qs'

// 登录接口

function Login(data,loadings){
	return new Promise((resolve,reject)=>{
		request.post(
			"/member/index_login.php",
			qs.stringify(data),
			loadings
		).then(res=>{
			resolve(res)
		}).catch(err=>{
			reject(err)
		})
	})
}

// 获取用户信息
function GetUserInfo(){
	return new Promise((resolve,reject)=>{
		request.get('/member/ajax_login.php')
		.then(res=>{
			resolve(res)
		}).catch(err=>{
			reject(err)
		})
	})
}

// 注册接口
function Register(data,loadings){
	return new Promise((resolve,reject)=>{
		request.post('member/reg_new2.php',qs.stringify(data),loadings)
		.then(res=>{
			resolve(res)
		}).catch(err=>{
			reject(err)
		})
	})
}


// 导出方法
export {Login,GetUserInfo,Register}