//存放分类模块 请求数据的方法 ANGLE_instanced_arrays

// 引入request  封装好的axios
import request from '@/utils/request.js'
import qs from 'qs'

// 定义一个获取分类方法

function GetCate(url,loadings){
	return new Promise((resolve,reject)=>{
		request.get(
			url,
			loadings
		).then(res=>{
			resolve(res)
		}).catch(err=>{
			reject(err)
		})
	})
}

// 导出分类的方法
export {GetCate}