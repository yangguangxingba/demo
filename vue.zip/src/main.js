import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

// 全局引入一个初始化css
import "./assets/css/reset.css"
// 全局引入一个转换移动端rem的工具
import "./assets/js/flexible.min.js"

// // 全局导入mockjs的配置
// import './mock/mock.js'

// 引入vant组件
import Vant from 'vant'
// 引入vant的样式文件
import 'vant/lib/index.css'

// vant组件icon图标
import { Icon } from 'vant';
Vue.use(Icon);

// vant组件导航栏
import { NavBar } from 'vant';
Vue.use(NavBar);

// vant组件标签页
import { Tab, Tabs } from 'vant';
Vue.use(Tab);
Vue.use(Tabs);

// 引入字体图标库样式
import './assets/iconfont/iconfont.css'

Vue.use(Vant)

// 引入vant轮播图
import { Swipe, SwipeItem } from 'vant';
Vue.use(Swipe);
Vue.use(SwipeItem);

// vant倒计时
import { CountDown } from 'vant';
Vue.use(CountDown);

// vant空状态
import { Empty } from 'vant';
Vue.use(Empty);

// vant商品导航
import { GoodsAction, GoodsActionIcon, GoodsActionButton } from 'vant';
Vue.use(GoodsAction);
Vue.use(GoodsActionButton);
Vue.use(GoodsActionIcon);

// vant 提交订单栏
import { SubmitBar } from 'vant';
Vue.use(SubmitBar);

// vant 复选框
import { Checkbox, CheckboxGroup } from 'vant';
Vue.use(Checkbox);
Vue.use(CheckboxGroup);

// vant 步进器
import { Stepper } from 'vant';
Vue.use(Stepper);

// vant 轻提示
// import { Toast } from 'vant';
// Vue.use(Toast);


Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
