function waterfull(parent,son,col,gap){
			var con=document.querySelector(parent)
			var pbls=document.querySelectorAll(son)
			con.style.position="relative"
			var arr= new Array(col)  //数组长度参照列数
			arr.fill(0)		//给数组每个值默认为0
			// var gap=10  //间距
			var w=(con.offsetWidth-gap*(col+1))/col		//获取每个小div宽度
			for(var i=0;i<pbls.length;i++){
				pbls[i].style.position="absolute"
				var min=Math.min(...arr)
				var minIndex=arr.indexOf(min)
				pbls[i].style.width=w+'px'
				pbls[i].style.left=(minIndex+1)*gap+minIndex*w+'px'
				pbls[i].style.top=min+'px'
				arr[minIndex]=min+pbls[i].offsetHeight+gap
			}
		}
export {waterfull}