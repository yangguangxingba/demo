// 用于存放 请求方法的文件，（封装axios）


import axios from 'axios'
import qs from 'qs'
import jsonp from 'jsonp'
import { Toast } from 'vant'

// 1 创建实例
var request = axios.create({
	baseURL: '/',  //默认的url 请求域名
	timeout:5000,	//请求超时
	headers: {		//请求头
		get: {
			"source_type": 504
		}
	}
})

//2 配置拦截

// 请求开始
request.interceptors.request.use(
function(config){
	// console.log(config)
	if(config.loadings != 1){
		Toast.loading({
		  message: '加载中...',
		  forbidClick: true,
		  loadingType: 'spinner',
		})
	}
	return config
},
// promise  里面两个参数  reject  resolve
// 处理错误
function(err){
	Toast.clear();
	Promise.reject(err)
}
)

// 请求完毕
request.interceptors.response.use(
function(res){
	Toast.clear();
	return res
},
// 处理错误
function(err){
	Toast.clear();
	Promise.reject(err)
}
)

// 3 写一个扩展方法
request.jsonp = function(url,opts){
	return new Promise((resolve,reject)=>{
		jsonp(url,opts,function(err,data){
			if(err){reject(err)}
			if(data){resolve(data)}
		})
	})
}

// 4 导出
export default request