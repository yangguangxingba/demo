import Vue from 'vue'
import Vuex from 'vuex'
import { GetUserInfo } from '@/api/user/user.js'
import { Dialog } from 'vant';
Vue.use(Dialog);
import { Notify } from 'vant';
Vue.use(Notify);

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
	  // 用户信息
	  userInfo:{},
	  goods:[]
  },
  getters: {
	  'totalNum':function(state){
		  var n = 0;
		 state.goods.forEach(item => {
		 		n += item.shuliang
		 })
		 return n
	  },
	  'totalPrice': function(state) {
	  	var n = 0;
	  	state.goods.forEach(item => {
	  		if (item.checked) {
	  			n += item.shuliang * item.price
	  		}
	  	})
	  	return n
	  }
  },
  mutations: {
	  // 全选方法
	  checkAll(state,check){
		  state.goods.forEach(item=>{
			  item.checked=check
		  })
	  },
	  
	  // 获取用户信息
	  initUserInfo(state,userInfo){
	  	state.userInfo=userInfo
	  },
	  
	  // 添加商品
	  addGoods(state,good){
			var flag=true
		  good.checked=true
		  state.goods.forEach(value=>{
			  if(value.id==good.id){
				  value.shuliang+=1
				  flag=false
			  }
		  })
		  if(flag){
			  good.shuliang=1
			  state.goods.unshift(good)
		  }
		  Notify({ type: 'success', message: '商品已放入购物车~' }); 
	  },
	  
	  // 删除商品
	  delCart(state, item) {
	  	Dialog.confirm({
	  			title: '警告',
	  			message: '确定要删除该商品吗',
	  		})
	  		.then(() => {
	  			// on confirm
	  			var ind = state.goods.findIndex(value => {
	  				return value.id == item.id
	  			})
	  			state.goods.splice(ind, 1)
				Notify({ type: 'warning', message: '商品已移除~' });
	  		})
	  		.catch(() => {
				
	  		});
	  }
  },
  actions: {
	  // 获取用户信息
	  getUserInfo(context){
	  	GetUserInfo().then(res=>{
	  		context.commit('initUserInfo',res.data)
	  	}).catch(err=>{
	  		console.log(err)
	  	})
	  }
  },
  modules: {
  }
})
